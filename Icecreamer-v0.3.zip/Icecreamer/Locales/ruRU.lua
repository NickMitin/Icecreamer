Icecreamer__locale["ruRU"] = {
    ["%s has been icecreamed %d times"] = "%s был отморожен %d раз",
    ["%s never been icecreamed"] = "%s ещё не отморожен",
    ["Icecream attempt. Icecream present: %d, trade session started: %d, trade session success: %d"] = "Попытка отморожения. Мороженое есть в списке: %d, торговля начата: %d, торговля успешна: %d",
    ["Icecreamed players discovery enabled"] = "Обнаружение отмороженых игроков включено",
    ["Icecreamed players discovery disabled"] = "Обнаружение отмороженых игроков выключено",
    ["on and off arguments only supported"] = "Поддерживаются только аргументы on и off",
    ["%s might not want Icecream. Ask first"] = "%s возможно не хочет мороженое, лучше сначала спросить",
    ["Out of icecream!"] = "|cffff0000Мороженое кончилось!",
}