Icecreamer__locale["enUS"] = {
    ["%s has been icecreamed %d times"] = "%s has been icecreamed %d times",
    ["%s never been icecreamed"] = "%s never been icecreamed",
    ["Icecream attempt. Icecream present: %d, trade session started: %d, trade session success: %d"] = "Icecream attempt. Icecream present: %d, trade session started: %d, trade session success: %d",
    ["Icecreamed players discovery enabled"] = "Icecreamed players discovery enabled",
    ["Icecreamed players discovery disabled"] = "Icecreamed players discovery disabled",
    ["on and off arguments only supported"] = "on and off arguments only supported",
    ["%s might not want Icecream. Ask first"] = "%s might not want Icecream. Ask first",
    ["Out of icecream!"] = "|cffff0000Out of ice cream!",
}